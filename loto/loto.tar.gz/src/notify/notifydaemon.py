import time
import pprint
from textwrap import dedent
import shelve
from datetime import datetime
import os

from data.fetch import fetch_remote_item_data
from data.fetch import save_item_data
from analysis.statistics import extract_stats
from sendmail import send
from settings import NOTIFY_FROM
from settings import NOTIFY_TO
from settings import NOTIFY_LOG
from settings import ANALYSIS_NUM_CHOOSER

SUBJECT = 'notify %s %s'

current_decider = ANALYSIS_NUM_CHOOSER

def _log(data,index):
    instance = data[index]
    prev_instance = data[index - 1]

    date = instance['date']
    nums = instance['nums']

    stats = extract_stats(data,index)
    stats_prev = extract_stats(data,index-1)
    prediction = current_decider(stats)
    prediction_prev = current_decider(stats_prev)

    outcome = 'SUCCESS' if prediction_prev in nums else 'FAIL'

    return {'date':date,
            'nums':nums,
            'prediction_prev':prediction_prev,
            'prediction':prediction,
            'predictor':current_decider.__name__,
            'outcome':outcome,
            'stats':stats}

def fetch_and_save_data():
    data = list(fetch_remote_item_data())
    save_item_data(data)
    return data

def run(force=False):

    db = shelve.open(".db")
    data = list(fetch_and_save_data())

    end_index = len(data)-1
    begin_index = end_index - NOTIFY_LOG

    format = lambda d: '%(date)s - %(nums)s - %(prediction_prev)d - %(outcome)s' % d
    log_dicts = [_log(data,i) for i in range(begin_index,end_index+1)]

    last_log_dict = log_dicts[-1]
    date = last_log_dict['date']
    current_date = datetime.now().strftime('%d.%m. %H:00')

    notify = force or (db.get("date",None)!=date and current_date == date)

    if notify:
        db["date"] = date
        nums = last_log_dict['nums']
        prediction_prev = last_log_dict['prediction_prev']
        outcome = last_log_dict['outcome']
        prediction_next = last_log_dict['prediction']
        last_seen = '  '.join([str(v) for v in last_log_dict['stats']['last_seen']])
        percent_10 = '  '.join(['%.2f' % round(percent,2) for percent in last_log_dict['stats']['percents'][10]])

        back_log = '\n'.join([format(log_dict) for log_dict in reversed(log_dicts[:-1])])

        subject = SUBJECT % (date,outcome)
        body=dedent('''\
            date: %(date)s
            nums: %(nums)s
            prediction(prev): %(prediction_prev)d - %(outcome)s
            prediction(next): %(prediction_next)d
            last seen: %(last_seen)s
            percent 10: %(percent_10)s

            log:
            %(back_log)s
            ''') % vars()

        send(subject,NOTIFY_FROM,NOTIFY_TO,body)
    else:
        print 'ignored - notification already sent or results not available yet'

    db.close()

if __name__ == '__main__':
    #run()
    run(force=True)